export { default } from './DialogContentText';
export * from './DialogContentText';
