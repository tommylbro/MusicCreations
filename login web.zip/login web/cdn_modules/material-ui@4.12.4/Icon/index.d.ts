export { default } from './Icon';
export * from './Icon';
