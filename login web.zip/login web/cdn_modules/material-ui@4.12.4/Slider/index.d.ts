export { default } from './Slider';
export * from './Slider';
